
public class Comercio {
	private String nombre, apellidos, DNI, contrasenya;
	
	public Comercio(String nombre, String apellidos, String DNI, String contrasenya) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.DNI = DNI;
		this.contrasenya = contrasenya;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getApellidos() {
		return apellidos;
	}
	
	public String getDNI() {
		return DNI;
	}
	
	public String getContrasenya() {
		return contrasenya;
	}
}
