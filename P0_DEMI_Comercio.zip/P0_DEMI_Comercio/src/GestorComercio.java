import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class GestorComercio {
	
	private Contenedor comercios;
	private static final String delimitador = ";";
	
	public GestorComercio () {
		comercios = new Contenedor(200);
		cargarDatosComercios();
	}

	/* Comprobamos que el usuario y contrasenya introducidos son correctos
	 * (primero se comprueba que existe el usuario, y luego, en caso de existir, 
	 * comprobamos que la contrasenya introducida es correcta) */
	public boolean login(String DNI, String contrasenya) {
		
		Comercio auxComercio = existeComercio(DNI);
		
		if (auxComercio != null) {
			if (auxComercio.getContrasenya().equals(contrasenya)) {
				return true;
			}
		}
		
		return false;
	}
	
	/*  En los prototipos posteriores (cuando se integren comercio y
	 *  servidor)esto lo hará el servidor.
	 *  Si encuentra al comercio, devolvemos su contraseña para comprobarla
	 *  con la intriducida*/
	private Comercio existeComercio(String DNI) {
		
		Object auxComercio = null;
		boolean encontrado = false;
		
		comercios.iniciarRecorrido();
        while (comercios.haySiguiente() && !encontrado) {
  
        	auxComercio = comercios.siguiente();
            if (auxComercio != null && ((Comercio)auxComercio).getDNI().equals(DNI) ) {
            		encontrado = true;
            }else {
            		auxComercio = null;
            }
        }
        return (Comercio) auxComercio;
	}
	
	public boolean registro(String nombre, String apellidos, String DNI, String contrasenya) {
		
		//Si no existe el comercio se permite el nuevo registro.
		if(existeComercio(DNI) == null){
			comercios.introducir(new Comercio(nombre, apellidos, DNI, contrasenya));
			guardarDatosComercio(nombre, apellidos, DNI, contrasenya);
			return true;
		}
		return false;
	}
	
	private void guardarDatosComercio(String nombre, String apellidos, String DNI, String contrasenya) {
		
		BufferedWriter bw = null;
	    FileWriter fw = null;

	    try {
	        File file = new File("comercios.txt");
	        // Si el archivo no existe, se crea!
	        if (!file.exists()) {
	            file.createNewFile();
	        }
	        // flag true, indica adjuntar información al archivo.
	        fw = new FileWriter(file.getAbsoluteFile(), true);
	        bw = new BufferedWriter(fw);
	        bw.write("\n"+nombre+delimitador+apellidos+delimitador+DNI+delimitador+contrasenya+delimitador);
	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            //Cierra instancias de FileWriter y BufferedWriter
	            if (bw != null)
	                bw.close();
	            if (fw != null)
	                fw.close();
	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	    }
	}
	
	/* Simulamos los datos de los comercios cogiéndolos de un archivo donde
	 * estan almacenados sus datos (incluyendo sus credenciales) y los 
	 * guardamos en memoria en una clase llamada Contenedor (permite guardar 
	 * objetos genéricos) */
	private void cargarDatosComercios() {
		
		 String separador=";";
	     BufferedReader br = null;
	     Comercio auxComercio = null;
	      
	      try {
	         
	         br =new BufferedReader(new FileReader("comercios.txt"));
	         String line = br.readLine();
	         
	         while (line != null) {
	            String [] campos = line.split(separador);
	            auxComercio = new Comercio (campos[0], campos[1], campos[2], campos[3]);
	            comercios.introducir(auxComercio);
	            line = br.readLine();
	         }
	         
	      } catch (Exception e) {
	         System.out.println(e);
	      } finally {
	         if (null!=br) {
	            try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
	         }
	      }
	}
}
