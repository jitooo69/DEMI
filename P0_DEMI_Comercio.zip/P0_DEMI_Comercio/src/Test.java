import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String usuario, contrasenya, opcion, nombre, apellidos;
		
		GestorComercio gestorCliente = new GestorComercio();
		
		System.out.print("Aplicación ¿Dónde está mi IVA?\nEscoja una opción.\n"
				+ "1 - Acceder \n2 - Registro\n3 - Salir\nOpción: ");
		opcion = sc.next();
		
		switch (opcion) {
		case "1":
			System.out.println("Introduzca sus credenciales para acceder.");
			System.out.print("Usuario: ");
			usuario = sc.next();
			System.out.print("Contrasenya: ");
			contrasenya = sc.next();
			
			if (gestorCliente.login(usuario, contrasenya)) {
				System.out.println("Usuario logueado con éxito");
			}else{
				System.out.println("Login incorrecto");
			}
			break;
			
		case "2":
			System.out.print("Nombre: ");
			nombre = sc.next();
			System.out.print("Apellidos: ");
			apellidos = sc.next();
			System.out.print("DNI: ");
			usuario = sc.next();
			System.out.print("Contrasenya: ");
			contrasenya = sc.next();
			
			if (gestorCliente.registro(nombre, apellidos, usuario, contrasenya)) {
				System.out.println("Usuario registrado con éxito");
			}else{
				System.out.println("Registro no realizado");
			}
			break;
			
		case "3":
			System.exit(0);

		default:
			System.out.println("Opción inválida");
			break;
		}
		

	}

}
