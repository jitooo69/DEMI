import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class GestorCliente {
	
	private Contenedor clientes;
	private static final String delimitador = ";";
	
	public GestorCliente () {
		clientes = new Contenedor(200);
		cargarDatosClientes();
	}

	/* Comprobamos que el usuario y contrasenya introducidos son correctos
	 * (primero se comprueba que existe el usuario, y luego, en caso de existir, 
	 * comprobamos que la contrasenya introducida es correcta) */
	public boolean login(String DNI, String contrasenya) {
		
		Cliente auxCliente = existeCliente(DNI);
		
		if (auxCliente != null) {
			if (auxCliente.getContrasenya().equals(contrasenya)) {
				return true;
			}
		}
		
		return false;
	}
	
	/*  En los prototipos posteriores (cuando se integren cliente y
	 *  servidor)esto lo hará el servidor.
	 *  Si encuentra al cliente, devolvemos su contraseña para comprobarla
	 *  con la intriducida*/
	private Cliente existeCliente(String DNI) {
		
		Object auxCliente = null;
		boolean encontrado = false;
		
		clientes.iniciarRecorrido();
        while (clientes.haySiguiente() && !encontrado) {
  
        	auxCliente = clientes.siguiente();
            if (auxCliente != null && ((Cliente)auxCliente).getDNI().equals(DNI) ) {
            		encontrado = true;
            }else {
            		auxCliente = null;
            }
        }
        return (Cliente) auxCliente;
	}
	
	public boolean registro(String nombre, String apellidos, String DNI, String contrasenya) {
		
		//Si no existe el cliente se permite el nuevo registro.
		if(existeCliente(DNI) == null){
			clientes.introducir(new Cliente(nombre, apellidos, DNI, contrasenya));
			guardarDatosCliente(nombre, apellidos, DNI, contrasenya);
			return true;
		}
		return false;
	}
	
	private void guardarDatosCliente(String nombre, String apellidos, String DNI, String contrasenya) {
		
		BufferedWriter bw = null;
	    FileWriter fw = null;

	    try {
	        File file = new File("clientes.txt");
	        // Si el archivo no existe, se crea!
	        if (!file.exists()) {
	            file.createNewFile();
	        }
	        // flag true, indica adjuntar información al archivo.
	        fw = new FileWriter(file.getAbsoluteFile(), true);
	        bw = new BufferedWriter(fw);
	        bw.write("\n"+nombre+delimitador+apellidos+delimitador+DNI+delimitador+contrasenya+delimitador);
	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            //Cierra instancias de FileWriter y BufferedWriter
	            if (bw != null)
	                bw.close();
	            if (fw != null)
	                fw.close();
	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	    }
	}
	
	/* Simulamos los datos de los clientes cogiéndolos de un archivo donde
	 * estan almacenados sus datos (incluyendo sus credenciales) y los 
	 * guardamos en memoria en una clase llamada Contenedor (permite guardar 
	 * objetos genéricos) */
	private void cargarDatosClientes() {
		
		 String separador=";";
	     BufferedReader br = null;
	     Cliente auxCliente = null;
	      
	      try {
	         
	         br =new BufferedReader(new FileReader("clientes.txt"));
	         String line = br.readLine();
	         
	         while (line != null) {
	            String [] campos = line.split(separador);
	            auxCliente = new Cliente (campos[0], campos[1], campos[2], campos[3]);
	            clientes.introducir(auxCliente);
	            line = br.readLine();
	         }
	         
	      } catch (Exception e) {
	         System.out.println(e);
	      } finally {
	         if (null!=br) {
	            try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
	         }
	      }
	}
}
